package com.aug.flightbooking.infrastructure.persistence.adapters;

import com.aug.flightbooking.application.ports.out.ReservationRepository;
import com.aug.flightbooking.domain.models.reservation.Reservation;
import com.aug.flightbooking.infrastructure.persistence.entities.ReservationEntity;
import com.aug.flightbooking.infrastructure.persistence.mappers.ReservationMapper;
import com.aug.flightbooking.infrastructure.persistence.repositories.R2dbcReservationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

@Component
@RequiredArgsConstructor
public class ReservationRepositoryAdapter implements ReservationRepository {

    private final R2dbcReservationRepository repository;

    @Override
    public Mono<Reservation> save(Reservation reservation) {
        ReservationEntity entity = ReservationMapper.toEntity(reservation);
        return repository.save(entity)
                .map(ReservationMapper::toDomain);
    }

    @Override
    public Mono<Reservation> findById(Long id) {
        return repository.findById(id)
                .map(ReservationMapper::toDomain);
    }

    @Override
    public Flux<Reservation> findReservationsBefore(Instant threshold, List<String> statuses) {
        return repository.findByStatusesAtBefore(statuses, threshold)
                .map(ReservationMapper::toDomain);
    }

    @Override
    public Flux<Reservation> findAll() {
        return repository.findAll()
                .map(ReservationMapper::toDomain);
    }
}
